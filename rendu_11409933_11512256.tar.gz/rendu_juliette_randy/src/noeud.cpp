#include "noeud.hpp"

namespace MMaze {


    Noeud::Noeud(int t, int c) {
        
    }

    Noeud::~Noeud() {
        
    }
}